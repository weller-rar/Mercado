import { Component, AfterViewInit, ElementRef, ViewChildren, QueryList } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-inicio',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './inicio.component.html',
  styleUrl: './inicio.component.css'
})
export class InicioComponent implements AfterViewInit {
  @ViewChildren('restCard, catCard') cards!: QueryList<ElementRef>;

  searchText: string = '';
  activeNavIndex: number = 0;

  ngAfterViewInit() {
    // Implement intersection observer for staggered card animation
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, i) => {
        if (entry.isIntersecting) {
          const el = entry.target as HTMLElement;
          el.style.animationDelay = (i * 60) + 'ms';
          el.style.animation = 'fadeUp .5s ease both';
          observer.unobserve(el);
        }
      });
    }, { threshold: 0.12 });

    this.cards.forEach(card => observer.observe(card.nativeElement));
  }

  setSearchText(text: string) {
    // Remove emojis from tags
    const cleanText = text.replace(/[\u{1F300}-\u{1FFFF}]/gu, '').trim();
    this.searchText = cleanText;
  }

  setActiveNav(index: number) {
    this.activeNavIndex = index;
  }
}
